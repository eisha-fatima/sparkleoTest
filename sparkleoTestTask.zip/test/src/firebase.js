import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyDEpp1wWycBqxkvgNHhAtI_m0sfthRrchQ",
  authDomain: "sparkleo-d3a29.firebaseapp.com",
  projectId: "sparkleo-d3a29",
  storageBucket: "sparkleo-d3a29.appspot.com",
  messagingSenderId: "779451230342",
  appId: "1:779451230342:web:ed80d7d200667690a64907",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
