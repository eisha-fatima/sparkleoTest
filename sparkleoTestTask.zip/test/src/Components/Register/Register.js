import React from "react";
import { useState, useEffect } from "react";
import { db } from "../../firebase";
import { addDoc } from "firebase/firestore";
import "./Register.css";
import Dashboard from "../Dashboard/Dashboard";
import { collection, onSnapshot } from "firebase/firestore";

const Register = () => {
  const [firstName, setfirstName] = useState("");
  const [lastName, setlastName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [employees, setEmployees] = useState([]);

  const addEmployee = (e) => {
    e.preventDefault();
    const channelRef = collection(db, "employees");
    addDoc(channelRef, {
      firstname: firstName,
      lastName: lastName,
      email: email,
      phone: phone,
    });
  };

  useEffect(() => {
    const empCollRef = collection(db, "employees");

    onSnapshot(empCollRef, (snapshot) => {
      setEmployees(
        snapshot.docs.map((doc) => ({
          id: doc.id,
          data: doc.data(),
        }))
      );
    });
  }, []);

  const clearAll = () => {
    setEmail("");
    setfirstName("");
    setlastName("");
    setPhone("");
  };
  return (
    <div className="mainBox">
      <div className="register">
        <div className="register__Container">
          <div className="registerForm">
            <form onSubmit={addEmployee}>
              <div className="registerForm_Header">
                <p>New Employee</p>
              </div>
              <div className="registerForm__inputBox">
                <p>First Name:</p>
                <input
                  type="text"
                  name="firstName"
                  value={firstName}
                  onChange={(e) => setfirstName(e.target.value)}
                />
              </div>

              <div className="registerForm__inputBox">
                <p>Last Name:</p>
                <input
                  type="text"
                  name="lastName"
                  value={lastName}
                  onChange={(e) => setlastName(e.target.value)}
                />
              </div>
              <div className="registerForm__inputBox">
                <p>Email:</p>
                <input
                  type="email"
                  name="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              <div className="registerForm__inputBox">
                <p>Phone:</p>
                <input
                  type="number"
                  name="phone"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                />
              </div>
              <div className="bottomButtons">
                <p onClick={clearAll}>Clear All</p>
                <button type="submit">ADD</button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div className="dashboardBox">
        <Dashboard employees={employees} />
      </div>
    </div>
  );
};

export default Register;
