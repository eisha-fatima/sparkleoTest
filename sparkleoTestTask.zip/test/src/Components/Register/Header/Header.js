import React from "react";
import "./Header.css";
import StarOutlineIcon from "@mui/icons-material/StarOutline";
const Header = () => {
  return (
    <div className="header">
      <div className="header__left">
        <StarOutlineIcon />
        <h4>Sparkleo</h4>
      </div>
      <div className="header__right">
        <p>Employee Management</p>
      </div>
    </div>
  );
};

export default Header;
