import React from "react";
import "./Dashboard.css";
import Employee from "./Employee/Employee";

const Dashboard = ({ employees }) => {
  console.log(employees);
  return (
    <div className="dashboard">
      <div className="dashboardetails">
        <h2>Current Employees</h2>
        {employees.map((employee) => (
          <Employee
            firstname={employee.data.firstname}
            lastName={employee.data.lastName}
            email={employee.data.email}
            phone={employee.data.phone}
            key={employee.id}
            id={employee.id}
          />
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
