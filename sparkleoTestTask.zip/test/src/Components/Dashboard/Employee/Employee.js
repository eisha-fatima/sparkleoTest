import React from "react";
import CancelIcon from "@mui/icons-material/Cancel";
import "./Employee.css";
import { deleteDoc, doc } from "firebase/firestore";
import { db } from "../../../firebase";

const Employee = ({ firstname, lastName, email, phone, id }) => {
  const deleteEmployee = () => {
    const empRef = doc(db, "employees", id);
    deleteDoc(empRef);
  };

  return (
    <div className="employee">
      <div className="details">
        <h3>
          {firstname} {lastName}
        </h3>
        <p>{email}</p>
        <p className="phone">+{phone}</p>
      </div>
      <div className="delete">
        <CancelIcon onClick={deleteEmployee} />
      </div>
    </div>
  );
};

export default Employee;
