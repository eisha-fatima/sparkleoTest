import React from "react";
import Register from "./Components/Register/Register";

import Header from "./Components/Register/Header/Header";
const App = () => {
  return (
    <div>
      <Header />
      <div>
        <Register />
      </div>
    </div>
  );
};

export default App;
