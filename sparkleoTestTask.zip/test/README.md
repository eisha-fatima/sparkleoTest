## How to Run

# Open yhe project Folder.

# In the terminal navigate to the projwct folder (i.e. test)

# Run the command `npm install`

# This will install a folder called node_moduels

# After this run the command `npm start`

# This will start the project
